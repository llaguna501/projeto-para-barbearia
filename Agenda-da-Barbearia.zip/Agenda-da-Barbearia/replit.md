# BARBEARIA DO LAGUNA

Site de agendamento da BARBEARIA DO LAGUNA, com horários de segunda a sábado e bloqueio de reservas duplicadas.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Interface: React + Vite
- API de agendamento: Python 3, biblioteca padrão e SQLite
- Contrato da API: OpenAPI + Orval

## Where things live

- `artifacts/barbearia/` — interface pública do agendamento
- `artifacts/api-server/server.py` — API Python, horários e persistência das reservas
- `lib/api-spec/openapi.yaml` — contrato da API
- `artifacts/api-server/.replit-artifact/artifact.toml` — serviço Python no caminho `/api`

## Architecture decisions

- A API valida novamente todos os dados recebidos; a interface não é a única camada de proteção.
- O banco SQLite usa uma restrição única em `date` + `time` para impedir reservas concorrentes no mesmo horário.
- Os horários disponíveis são fixos de 09:00 a 18:00, com atendimentos de uma hora, de segunda a sábado.

## Product

- O cliente escolhe uma data, serviço e horário livre, informa nome e telefone e recebe a confirmação do agendamento.
- Domingos e horários já reservados são bloqueados pelo servidor.

## User preferences

- O usuário pediu que o sistema fosse feito em Python.

## Gotchas

- O workflow da API precisa executar `python3 artifacts/api-server/server.py`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
