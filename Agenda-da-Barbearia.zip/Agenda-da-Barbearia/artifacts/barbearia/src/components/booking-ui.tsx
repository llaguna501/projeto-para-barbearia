import { CalendarDays, Check, ChevronRight, Clock3, MapPin, Phone, RefreshCw, Scissors, ShieldCheck, UserRound } from 'lucide-react';
import type { Availability, Booking } from '@workspace/api-client-react';

type SlotGridProps = {
  availability?: Availability;
  selectedTime: string;
  onSelect: (time: string) => void;
  isLoading: boolean;
};

export function BrandMark() {
  return (
    <div className="flex items-center gap-3" data-testid="brand-mark">
      <div className="flex h-10 w-10 items-center justify-center rounded-[13px] bg-primary text-primary-foreground shadow-[4px_4px_0_hsl(var(--foreground))]">
        <Scissors size={21} strokeWidth={2.4} aria-hidden="true" />
      </div>
      <div className="leading-none">
        <p className="font-serif text-[17px] font-bold tracking-[-.04em]">BARBEARIA DO</p>
        <p className="font-serif text-[17px] font-bold tracking-[-.04em] text-primary">LAGUNA</p>
      </div>
    </div>
  );
}

export function BookingHeader() {
  return (
    <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 sm:px-8 lg:px-10" data-testid="site-header">
      <BrandMark />
      <div className="hidden items-center gap-2 text-xs font-semibold uppercase tracking-[.16em] text-muted-foreground sm:flex">
        <span className="h-2 w-2 rounded-full bg-[#4f8c70]" />
        Atendimento de segunda a sábado
      </div>
      <a href="#booking-form" className="focus-ring flex items-center gap-1 text-sm font-bold text-foreground transition-colors hover:text-primary sm:hidden" data-testid="link-book-now">
        Agendar <ChevronRight size={15} aria-hidden="true" />
      </a>
    </header>
  );
}

export function StepMarker({ number, label, active = false }: { number: string; label: string; active?: boolean }) {
  return (
    <div className={`flex items-center gap-2 ${active ? 'text-foreground' : 'text-muted-foreground'}`} data-testid={`step-${number}`}>
      <span className={`flex h-7 w-7 items-center justify-center rounded-full border text-xs font-bold ${active ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card'}`}>{number}</span>
      <span className="text-[11px] font-bold uppercase tracking-[.15em]">{label}</span>
    </div>
  );
}

export function SlotGrid({ availability, selectedTime, onSelect, isLoading }: SlotGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4" aria-label="Carregando horários" data-testid="slots-loading">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => <div key={item} className="h-11 animate-soft-pulse rounded-xl bg-muted" />)}
      </div>
    );
  }

  if (!availability?.isOpen) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-muted/60 px-5 py-7 text-center" data-testid="empty-slots">
        <Clock3 className="mx-auto mb-3 text-muted-foreground" size={23} aria-hidden="true" />
        <p className="font-serif text-lg font-semibold">A barbearia descansa nesse dia.</p>
        <p className="mt-1 text-sm text-muted-foreground">Escolha um dia de segunda a sábado para ver os horários.</p>
      </div>
    );
  }

  const slots = availability.slots ?? [];
  const openSlots = slots.filter((slot) => slot.available);

  if (!openSlots.length) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-muted/60 px-5 py-7 text-center" data-testid="empty-slots">
        <Clock3 className="mx-auto mb-3 text-muted-foreground" size={23} aria-hidden="true" />
        <p className="font-serif text-lg font-semibold">Esse dia já está completo.</p>
        <p className="mt-1 text-sm text-muted-foreground">Tente outra data — vamos encontrar um horário para você.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4" data-testid="slots-grid">
      {slots.map((slot) => (
        <button
          type="button"
          key={slot.time}
          disabled={!slot.available}
          onClick={() => onSelect(slot.time)}
          aria-pressed={selectedTime === slot.time}
          aria-label={`${slot.time}${slot.available ? '' : ', indisponível'}`}
          data-testid={`slot-${slot.time.replace(':', '-')}`}
          className={`slot-button focus-ring rounded-xl border px-2 py-3 text-sm font-bold ${
            selectedTime === slot.time
              ? 'border-primary bg-primary text-primary-foreground shadow-[3px_3px_0_hsl(var(--foreground))]'
              : slot.available
                ? 'border-border bg-card text-foreground hover:border-primary hover:text-primary'
                : 'cursor-not-allowed border-border/70 bg-muted/50 text-muted-foreground/45 line-through'
          }`}
        >
          {slot.time}
        </button>
      ))}
    </div>
  );
}

export function BookingError({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-destructive" role="alert" data-testid="error-message">
      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-current text-xs font-bold">!</span>
      <div className="flex-1">
        <p className="text-sm font-bold">{message}</p>
        {onRetry && (
          <button type="button" onClick={onRetry} className="focus-ring mt-2 inline-flex items-center gap-1 text-xs font-bold underline underline-offset-4" data-testid="button-retry">
            <RefreshCw size={13} aria-hidden="true" /> Tentar novamente
          </button>
        )}
      </div>
    </div>
  );
}

export function BookingSummary({ date, time, service }: { date: string; time: string; service: string }) {
  return (
    <div className="rounded-2xl bg-secondary p-4 text-secondary-foreground" data-testid="booking-summary">
      <p className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-secondary-foreground/60">Seu horário</p>
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="font-serif text-lg font-bold">{date}</p>
          <p className="mt-0.5 text-sm text-secondary-foreground/70">{service}</p>
        </div>
        <span className="rounded-lg bg-accent px-3 py-2 font-serif text-lg font-bold text-accent-foreground">{time}</span>
      </div>
    </div>
  );
}

export function ConfirmationCard({ booking, onNewBooking }: { booking: Booking; onNewBooking: () => void }) {
  const formattedDate = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${booking.date}T12:00:00`));
  return (
    <main className="mx-auto flex w-full max-w-3xl flex-1 items-center px-5 py-10 sm:px-8 lg:py-16" data-testid="confirmation-state">
      <section className="relative w-full overflow-hidden rounded-[2rem] border border-border bg-card p-7 barber-shadow sm:p-12">
        <div className="absolute -right-20 -top-20 h-52 w-52 rounded-full bg-accent/40" aria-hidden="true" />
        <div className="relative">
          <div className="mb-7 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#4f8c70] text-card" data-testid="status-booking-confirmed">
            <Check size={32} strokeWidth={3} aria-hidden="true" />
          </div>
          <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#4f8c70]">Agendamento confirmado</p>
          <h1 className="max-w-xl font-serif text-4xl font-bold leading-[.98] tracking-[-.055em] sm:text-6xl">Está marcado. A cadeira é sua.</h1>
          <p className="mt-5 max-w-md text-[15px] leading-7 text-muted-foreground">Tudo certo, {booking.name.split(' ')[0]}. Guardamos seu horário e vamos te esperar de portas abertas.</p>
          <div className="my-8 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl bg-muted/70 p-4" data-testid="confirmation-date">
              <CalendarDays size={18} className="mb-5 text-primary" aria-hidden="true" />
              <p className="text-xs font-semibold text-muted-foreground">Data</p>
              <p className="mt-1 font-serif text-xl font-bold capitalize">{formattedDate}</p>
            </div>
            <div className="rounded-2xl bg-muted/70 p-4" data-testid="confirmation-time">
              <Clock3 size={18} className="mb-5 text-primary" aria-hidden="true" />
              <p className="text-xs font-semibold text-muted-foreground">Horário</p>
              <p className="mt-1 font-serif text-xl font-bold">{booking.time}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-border pt-5">
            <div>
              <p className="text-xs text-muted-foreground">Serviço escolhido</p>
              <p className="mt-1 font-bold" data-testid="confirmation-service">{booking.service}</p>
            </div>
            <button type="button" onClick={onNewBooking} className="focus-ring inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-bold transition-colors hover:border-primary hover:text-primary" data-testid="button-new-booking">
              Fazer outro agendamento <ChevronRight size={16} aria-hidden="true" />
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}

export function TrustNote() {
  return (
    <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs font-medium text-muted-foreground" data-testid="trust-note">
      <span className="inline-flex items-center gap-1.5"><ShieldCheck size={15} className="text-[#4f8c70]" aria-hidden="true" /> Horário reservado na hora</span>
      <span className="inline-flex items-center gap-1.5"><MapPin size={15} className="text-primary" aria-hidden="true" /> No coração do bairro</span>
    </div>
  );
}

export function FieldIcon({ type }: { type: 'name' | 'phone' }) {
  return type === 'name' ? <UserRound size={17} aria-hidden="true" /> : <Phone size={17} aria-hidden="true" />;
}