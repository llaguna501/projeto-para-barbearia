import { useEffect, useMemo, useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { CalendarDays, ChevronRight, Clock3, Scissors } from 'lucide-react';
import { getGetAvailabilityQueryKey, useCreateBooking, useGetAvailability } from '@workspace/api-client-react';
import type { Booking, BookingInput } from '@workspace/api-client-react';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { z } from 'zod';
import {
  BookingError,
  BookingHeader,
  BookingSummary,
  ConfirmationCard,
  FieldIcon,
  SlotGrid,
  StepMarker,
  TrustNote,
} from '@/components/booking-ui';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import './index.css';

const services = [
  { value: 'Corte clássico', detail: 'Tesoura, máquina e finalização' },
  { value: 'Barba e acabamento', detail: 'Toalha quente e contorno preciso' },
  { value: 'Corte + barba', detail: 'O combo completo da casa' },
  { value: 'Corte infantil', detail: 'Cuidado e paciência para os pequenos' },
] as const;

const bookingSchema = z.object({
  name: z.string().trim().min(2, 'Digite seu nome completo.').max(80, 'Use um nome mais curto.'),
  phone: z.string().trim().min(8, 'Digite um telefone válido.').max(30, 'Confira o telefone digitado.'),
  service: z.enum(['Corte clássico', 'Barba e acabamento', 'Corte + barba', 'Corte infantil'], { required_error: 'Escolha um serviço.' }),
  date: z.string().min(1, 'Escolha uma data.'),
  time: z.string().min(1, 'Escolha um horário.'),
});

type FormValues = BookingInput;
const queryClient = new QueryClient();

function todayString() {
  const now = new Date();
  if (now.getDay() === 0) {
    now.setDate(now.getDate() + 1);
  }
  const offset = now.getTimezoneOffset();
  return new Date(now.getTime() - offset * 60 * 1000).toISOString().slice(0, 10);
}

function formatDate(date: string) {
  if (!date) return '';
  return new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${date}T12:00:00`));
}

function getApiErrorMessage(error: unknown) {
  const candidate = error as { status?: number; response?: { status?: number; data?: { error?: string } }; data?: { error?: string }; message?: string } | undefined;
  const status = candidate?.status ?? candidate?.response?.status;
  if (status === 409) return 'Esse horário acabou de ser ocupado. Escolha outro para continuar.';
  if (status === 400) return candidate?.data?.error ?? candidate?.response?.data?.error ?? 'Confira os dados do agendamento e tente novamente.';
  return 'Não conseguimos confirmar agora. Verifique sua conexão e tente novamente.';
}

function Home() {
  const queryClient = useQueryClient();
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [selectedTime, setSelectedTime] = useState('');
  const initialDate = useMemo(() => todayString(), []);
  const form = useForm<FormValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: { name: '', phone: '', service: 'Corte clássico', date: initialDate, time: '' },
    mode: 'onTouched',
  });
  const selectedDate = form.watch('date');
  const selectedService = form.watch('service');
  const availabilityParams = useMemo(() => ({ date: selectedDate }), [selectedDate]);
  const availabilityQuery = useGetAvailability(availabilityParams, {
    query: { queryKey: getGetAvailabilityQueryKey(availabilityParams), staleTime: 15_000 },
  });
  const createBooking = useCreateBooking();

  useEffect(() => {
    setSelectedTime('');
    form.setValue('time', '', { shouldValidate: false });
  }, [selectedDate, form]);

  const chooseTime = (time: string) => {
    setSelectedTime(time);
    form.setValue('time', time, { shouldValidate: true, shouldTouch: true });
  };

  const onSubmit = (values: FormValues) => {
    if (!availabilityQuery.data?.slots.some((slot) => slot.time === values.time && slot.available)) {
      form.setError('time', { message: 'Esse horário não está mais disponível.' });
      return;
    }
    createBooking.mutate({ data: values }, {
      onSuccess: (booking) => {
        setConfirmedBooking(booking);
        queryClient.invalidateQueries({ queryKey: getGetAvailabilityQueryKey({ date: values.date }) });
      },
    });
  };

  const startNewBooking = () => {
    setConfirmedBooking(null);
    setSelectedTime('');
    form.reset({ name: '', phone: '', service: 'Corte clássico', date: initialDate, time: '' });
  };

  if (confirmedBooking) {
    return (
      <div className="paper-noise flex min-h-[100dvh] flex-col">
        <BookingHeader />
        <ConfirmationCard booking={confirmedBooking} onNewBooking={startNewBooking} />
        <footer className="mx-auto w-full max-w-6xl px-5 pb-6 text-center text-xs text-muted-foreground sm:px-8 lg:px-10">Barbearia do Laguna · feito para o seu tempo</footer>
      </div>
    );
  }

  const availabilityError = availabilityQuery.isError;
  const dateIsOpen = availabilityQuery.data?.isOpen;
  const hasTimeError = Boolean(form.formState.errors.time);

  return (
    <div className="paper-noise min-h-[100dvh]">
      <BookingHeader />
      <main className="mx-auto flex min-h-[calc(100dvh-82px)] w-full max-w-3xl items-start justify-center px-5 pb-12 pt-6 sm:px-8 sm:pt-10 lg:px-10 lg:pt-14">
        <section className="w-full max-w-[560px]">
          <div id="booking-form" className="animate-rise-in delay-2 rounded-[1.6rem] border border-border bg-card p-5 barber-shadow sm:p-7">
            <div className="mb-6 flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.17em] text-primary">Agendamento rápido</p>
                <h2 className="mt-2 font-serif text-3xl font-bold tracking-[-.05em]">Reserve sua cadeira</h2>
              </div>
              <div className="hidden h-11 w-11 items-center justify-center rounded-xl bg-accent text-accent-foreground sm:flex">
                <Scissors size={21} aria-hidden="true" />
              </div>
            </div>

            <div className="mb-7 flex items-center gap-3 border-b border-border pb-5">
              <StepMarker number="01" label="Dia e hora" active />
              <div className="h-px flex-1 bg-border" />
              <StepMarker number="02" label="Seus dados" />
            </div>

            <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
              <fieldset className="space-y-5" disabled={createBooking.isPending}>
                <legend className="sr-only">Escolha os detalhes do agendamento</legend>
                <div>
                  <label htmlFor="booking-date" className="mb-2.5 flex items-center gap-2 text-sm font-bold">
                    <CalendarDays size={16} className="text-primary" aria-hidden="true" /> Quando você vem?
                  </label>
                  <input
                    id="booking-date"
                    type="date"
                    min={initialDate}
                    {...form.register('date', { onChange: () => setSelectedTime('') })}
                    className="input-wash focus-ring h-12 w-full rounded-xl border border-input bg-muted/50 px-3.5 text-sm font-semibold text-foreground"
                    data-testid="input-date"
                  />
                  <p className="mt-2 text-xs text-muted-foreground">Atendemos de segunda a sábado, das 9h às 19h.</p>
                  {form.formState.errors.date && <p className="mt-1.5 text-xs font-semibold text-destructive" data-testid="error-date">{form.formState.errors.date.message}</p>}
                </div>

                <div>
                  <div className="mb-2.5 flex items-center justify-between gap-3">
                    <label className="flex items-center gap-2 text-sm font-bold"><Clock3 size={16} className="text-primary" aria-hidden="true" /> Horário</label>
                    {availabilityQuery.data?.dayName && <span className="text-xs font-semibold capitalize text-muted-foreground" data-testid="text-day-name">{availabilityQuery.data.dayName}</span>}
                  </div>
                  {availabilityError ? (
                    <BookingError message="Não foi possível carregar os horários desta data." onRetry={() => availabilityQuery.refetch()} />
                  ) : (
                    <SlotGrid availability={availabilityQuery.data} selectedTime={selectedTime} onSelect={chooseTime} isLoading={availabilityQuery.isLoading || availabilityQuery.isFetching} />
                  )}
                  {hasTimeError && <p className="mt-2 text-xs font-semibold text-destructive" data-testid="error-time">{form.formState.errors.time?.message}</p>}
                  {dateIsOpen && <p className="mt-2 text-right text-[11px] font-semibold text-muted-foreground" data-testid="text-slots-hint">Horários em blocos de 1 hora</p>}
                </div>

                <div>
                  <label htmlFor="booking-service" className="mb-2.5 block text-sm font-bold">Qual serviço combina com hoje?</label>
                  <select id="booking-service" {...form.register('service')} className="input-wash focus-ring h-12 w-full appearance-none rounded-xl border border-input bg-muted/50 px-3.5 text-sm font-semibold text-foreground" data-testid="select-service">
                    {services.map((service) => <option key={service.value} value={service.value}>{service.value} · {service.detail}</option>)}
                  </select>
                  {form.formState.errors.service && <p className="mt-1.5 text-xs font-semibold text-destructive" data-testid="error-service">{form.formState.errors.service.message}</p>}
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label htmlFor="booking-name" className="mb-2.5 block text-sm font-bold">Seu nome</label>
                    <div className="relative">
                      <FieldIcon type="name" />
                      <input id="booking-name" placeholder="Como podemos te chamar?" autoComplete="name" {...form.register('name')} className="input-wash focus-ring h-12 w-full rounded-xl border border-input bg-muted/50 pl-10 pr-3.5 text-sm text-foreground placeholder:text-muted-foreground/65" data-testid="input-name" />
                    </div>
                    {form.formState.errors.name && <p className="mt-1.5 text-xs font-semibold text-destructive" data-testid="error-name">{form.formState.errors.name.message}</p>}
                  </div>
                  <div>
                    <label htmlFor="booking-phone" className="mb-2.5 block text-sm font-bold">WhatsApp</label>
                    <div className="relative">
                      <FieldIcon type="phone" />
                      <input id="booking-phone" placeholder="(11) 99999-9999" autoComplete="tel" {...form.register('phone')} className="input-wash focus-ring h-12 w-full rounded-xl border border-input bg-muted/50 pl-10 pr-3.5 text-sm text-foreground placeholder:text-muted-foreground/65" data-testid="input-phone" />
                    </div>
                    {form.formState.errors.phone && <p className="mt-1.5 text-xs font-semibold text-destructive" data-testid="error-phone">{form.formState.errors.phone.message}</p>}
                  </div>
                </div>

                {selectedTime && <BookingSummary date={formatDate(selectedDate)} time={selectedTime} service={selectedService} />}
                {createBooking.isError && <BookingError message={getApiErrorMessage(createBooking.error)} />}

                <button type="submit" disabled={createBooking.isPending || !availabilityQuery.data?.isOpen} className="focus-ring group flex h-14 w-full items-center justify-between rounded-xl bg-primary px-5 text-left text-sm font-bold text-primary-foreground shadow-[4px_4px_0_hsl(var(--foreground))] transition-transform hover:translate-y-[-2px] hover:shadow-[4px_6px_0_hsl(var(--foreground))] disabled:cursor-not-allowed disabled:opacity-55 disabled:shadow-none disabled:hover:translate-y-0" data-testid="button-confirm-booking">
                  <span>{createBooking.isPending ? 'Confirmando seu horário…' : 'Confirmar agendamento'}</span>
                  <ChevronRight size={19} className="transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </button>
              </fieldset>
            </form>
            <p className="mt-4 text-center text-[11px] leading-5 text-muted-foreground">Ao confirmar, seu horário fica reservado para você.</p>
          </div>
        </section>
      </main>
      <footer className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 pb-6 text-xs text-muted-foreground sm:px-8 lg:px-10">
        <span>Barbearia do Laguna</span>
      </footer>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}