#!/usr/bin/env python3

from __future__ import annotations

import json
import os
import re
import sqlite3
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


PORT = int(os.environ.get("PORT", "8080"))
DB_PATH = Path(
    os.environ.get(
        "BOOKINGS_DB_PATH",
        "artifacts/api-server/data/barbearia-bookings.sqlite3",
    )
)
WEEKDAY_TIME_SLOTS = [f"{hour:02d}:00" for hour in range(9, 19)]
SATURDAY_TIME_SLOTS = [f"{hour:02d}:00" for hour in range(9, 17)]
DAY_NAMES = [
    "segunda-feira",
    "terça-feira",
    "quarta-feira",
    "quinta-feira",
    "sexta-feira",
    "sábado",
    "domingo",
]
SERVICES = {
    "Corte clássico",
    "Barba e acabamento",
    "Corte + barba",
    "Corte infantil",
}
PHONE_PATTERN = re.compile(r"^[0-9()+\-\s]{8,30}$")


def database() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout = 10000")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            service TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(date, time)
        )
        """
    )
    connection.commit()
    return connection


def validate_date(value: Any) -> datetime:
    if not isinstance(value, str):
        raise ValueError("Informe uma data válida.")
    try:
        parsed = datetime.strptime(value, "%Y-%m-%d")
    except ValueError as error:
        raise ValueError("Informe uma data válida.") from error
    if parsed.weekday() > 5:
        raise ValueError("A barbearia atende de segunda a sábado.")
    return parsed


def validate_time(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("Escolha um horário disponível.")
    return value


def slots_for_date(selected_date: datetime) -> list[str]:
    return (
        SATURDAY_TIME_SLOTS
        if selected_date.weekday() == 5
        else WEEKDAY_TIME_SLOTS
    )


def booking_from_row(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "phone": row["phone"],
        "service": row["service"],
        "date": row["date"],
        "time": row["time"],
        "createdAt": row["created_at"],
    }


class BookingHandler(BaseHTTPRequestHandler):
    server_version = "BarbeariaAPI/1.0"

    def log_message(self, format: str, *args: Any) -> None:
        # Keep the API workflow output concise and useful.
        print(f"{self.address_string()} - {format % args}")

    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        super().end_headers()

    def send_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.end_headers()

    def do_GET(self) -> None:
        parsed_url = urlparse(self.path)
        if parsed_url.path == "/api/healthz":
            self.send_json(200, {"status": "ok"})
            return

        if parsed_url.path != "/api/availability":
            self.send_json(404, {"error": "Rota não encontrada."})
            return

        query = parse_qs(parsed_url.query)
        date_value = query.get("date", [None])[0]
        try:
            selected_date = validate_date(date_value)
        except ValueError as error:
            self.send_json(400, {"error": str(error)})
            return

        connection = database()
        try:
            booked = {
                row["time"]
                for row in connection.execute(
                    "SELECT time FROM bookings WHERE date = ?",
                    (selected_date.strftime("%Y-%m-%d"),),
                )
            }
        finally:
            connection.close()

        self.send_json(
            200,
            {
                "date": selected_date.strftime("%Y-%m-%d"),
                "dayName": DAY_NAMES[selected_date.weekday()],
                "isOpen": True,
                "slots": [
                    {"time": time, "available": time not in booked}
                    for time in slots_for_date(selected_date)
                ],
            },
        )

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/bookings":
            self.send_json(404, {"error": "Rota não encontrada."})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(content_length))
        except (ValueError, json.JSONDecodeError):
            self.send_json(400, {"error": "Envie os dados do agendamento em JSON."})
            return

        if not isinstance(payload, dict):
            self.send_json(400, {"error": "Dados de agendamento inválidos."})
            return

        name = payload.get("name")
        phone = payload.get("phone")
        service = payload.get("service")
        try:
            selected_date = validate_date(payload.get("date"))
            time = validate_time(payload.get("time"))
            if time not in slots_for_date(selected_date):
                raise ValueError("Escolha um horário disponível.")
        except ValueError as error:
            self.send_json(400, {"error": str(error)})
            return

        if not isinstance(name, str) or not 2 <= len(name.strip()) <= 80:
            self.send_json(400, {"error": "Informe seu nome completo."})
            return
        if not isinstance(phone, str) or not PHONE_PATTERN.fullmatch(phone.strip()):
            self.send_json(400, {"error": "Informe um telefone válido."})
            return
        if service not in SERVICES:
            self.send_json(400, {"error": "Escolha um serviço válido."})
            return

        connection = database()
        try:
            connection.execute("BEGIN IMMEDIATE")
            created_at = datetime.now().astimezone().isoformat()
            cursor = connection.execute(
                """
                INSERT INTO bookings (name, phone, service, date, time, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    name.strip(),
                    phone.strip(),
                    service,
                    selected_date.strftime("%Y-%m-%d"),
                    time,
                    created_at,
                ),
            )
            row = connection.execute(
                "SELECT * FROM bookings WHERE id = ?", (cursor.lastrowid,)
            ).fetchone()
            connection.commit()
        except sqlite3.IntegrityError:
            connection.rollback()
            self.send_json(
                409,
                {"error": "Esse horário acabou de ser reservado. Escolha outro."},
            )
            return
        finally:
            connection.close()

        if row is None:
            self.send_json(500, {"error": "Não foi possível concluir o agendamento."})
            return
        self.send_json(201, booking_from_row(row))


if __name__ == "__main__":
    database().close()
    print(f"Barbearia API listening on port {PORT}")
    ThreadingHTTPServer(("0.0.0.0", PORT), BookingHandler).serve_forever()